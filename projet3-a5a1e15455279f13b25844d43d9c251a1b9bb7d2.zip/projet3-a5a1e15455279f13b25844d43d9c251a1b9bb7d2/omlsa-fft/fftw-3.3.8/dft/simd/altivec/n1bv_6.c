/* Generated automatically.  DO NOT EDIT! */
#define SIMD_HEADER "simd-support/simd-altivec.h"
#include "../common/n1bv_6.c"
