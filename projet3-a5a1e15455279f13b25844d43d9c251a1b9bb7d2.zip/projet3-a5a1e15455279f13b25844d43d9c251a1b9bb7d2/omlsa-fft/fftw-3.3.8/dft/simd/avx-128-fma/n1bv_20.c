/* Generated automatically.  DO NOT EDIT! */
#define SIMD_HEADER "simd-support/simd-avx-128-fma.h"
#include "../common/n1bv_20.c"
